package com.jpmc.training.sparkcore;

import java.util.Arrays;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import scala.Tuple2;

public class PairRddTest2 {
	public static void main(String[] args) {
		SparkConf conf=new SparkConf();
		conf.setMaster("local[*]");
		conf.setAppName("transformation-test-app");
		JavaSparkContext sc=new JavaSparkContext(conf);
		sc.setLogLevel("WARN");
		
		JavaRDD<String> rdd1=sc.textFile("c:/test/users.txt");
		rdd1.map(line->line.split("\t")).map(arr->new Tuple2<>(arr[0], arr[1])).collect().
		forEach(System.out::println);
				
	}

}
