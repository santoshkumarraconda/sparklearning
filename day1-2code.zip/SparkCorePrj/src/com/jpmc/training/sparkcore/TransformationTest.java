package com.jpmc.training.sparkcore;

import java.util.Arrays;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class TransformationTest {
	public static void main(String[] args) {
		SparkConf conf=new SparkConf();
		conf.setMaster("local[*]");
		conf.setAppName("transformation-test-app");
		JavaSparkContext sc=new JavaSparkContext(conf);
		List<Integer> list=Arrays.asList(12,55,22,8,10,28);
		
		JavaRDD<Integer> rdd1=sc.parallelize(list);
		rdd1.map(n->n*5).filter(n->n>=100).collect().forEach(System.out::println);
	}

}
