package com.jpmc.training.sparkcore;

import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class RDDCreationTest1 {
	public static void main(String[] args) {
		SparkConf conf=new SparkConf();
		conf.setMaster("local[*]");
		conf.setAppName("rdd-create-app");
		JavaSparkContext sc=new JavaSparkContext(conf);
		
		JavaRDD<String> rdd1=sc.textFile("c:/test/sample.txt");
		List<String> list= rdd1.collect();
		list.forEach(System.out::println);
	}

}
