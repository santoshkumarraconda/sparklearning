package com.jpmc.training.sparkcore;

import java.util.Arrays;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import scala.Tuple2;

public class WordCountTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SparkConf conf=new SparkConf();
		conf.setMaster("local[*]");
		conf.setAppName("transformation-test-app");
		JavaSparkContext sc=new JavaSparkContext(conf);
		sc.setLogLevel("WARN");
		
		JavaRDD<String> rdd1=sc.textFile("c:/test/words.txt");
		rdd1.flatMap(line->Arrays.asList(line.split(" ")).iterator())
		.mapToPair(word->new Tuple2<>(word,1)).reduceByKey((x,y)->x+y).collect().
		forEach(System.out::println);
		
	}

}
