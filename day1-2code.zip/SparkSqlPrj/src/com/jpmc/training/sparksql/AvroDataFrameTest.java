package com.jpmc.training.sparksql;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class AvroDataFrameTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SparkSession spark=SparkSession.builder().appName("dataframe-app")
				                .master("local[*]").getOrCreate();
		
		spark.sparkContext().setLogLevel("WARN");
		
		Dataset<Row> ds=spark.read().format("avro").option("header", true)
				.load("c:/testavro");
		ds.show();
				

	}

}
