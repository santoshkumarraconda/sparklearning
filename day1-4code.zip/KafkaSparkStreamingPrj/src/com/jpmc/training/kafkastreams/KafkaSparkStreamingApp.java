package com.jpmc.training.kafkastreams;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.spark.SparkConf;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka010.ConsumerStrategies;
import org.apache.spark.streaming.kafka010.KafkaUtils;
import org.apache.spark.streaming.kafka010.LocationStrategies;

import scala.Tuple2;



public class KafkaSparkStreamingApp {
public static void main(String[] args) {
	SparkConf conf=new SparkConf();
	conf.setMaster("local[*]");
	conf.setAppName("kafka-wordcount-stream-app");
	JavaStreamingContext streamingContext=new JavaStreamingContext(conf,Durations.seconds(60));
	streamingContext.sparkContext().setLogLevel("WARN");
	
	String topic="test-topic";
	String kafkaUrl="localhost:9092";
	
	Map<String, Object> props=new HashMap<>();
	props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaUrl);
	props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
	props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
	props.put(ConsumerConfig.GROUP_ID_CONFIG,"group-1");
	
	Collection<String> topicList=Collections.singletonList(topic);
	
	JavaInputDStream<ConsumerRecord<String, String>> dStream=
			KafkaUtils.createDirectStream(streamingContext, LocationStrategies.PreferConsistent(), 
					ConsumerStrategies.Subscribe(topicList, props));
	
	dStream.mapToPair(msg->new Tuple2<>(msg.key(),msg.value())).map(t->t._2).
			flatMap(line->Arrays.asList(line.split(" ")).iterator()).
	mapToPair(word->new Tuple2<>(word, 1)).reduceByKey((x,y)->x+y)
	.dstream().saveAsTextFiles("c:/wordcount/", "-fromkafka");
	streamingContext.start();
	
	System.out.println("streaming started");
	
	try {
		streamingContext.awaitTermination();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	
}
}
