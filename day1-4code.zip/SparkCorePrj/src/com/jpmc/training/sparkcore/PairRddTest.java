package com.jpmc.training.sparkcore;

import java.util.Arrays;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import scala.Tuple2;

public class PairRddTest {
	public static void main(String[] args) {
		SparkConf conf=new SparkConf();
		conf.setMaster("local[*]");
		conf.setAppName("transformation-test-app");
		JavaSparkContext sc=new JavaSparkContext(conf);
		sc.setLogLevel("WARN");
		
		List<Tuple2<String, Integer>> list=Arrays.asList(new Tuple2<>("a", 2),new Tuple2<>("a", 2),
				new Tuple2<>("b", 3),new Tuple2<>("a", 3));
		JavaPairRDD<String,Integer> rdd1=sc.parallelizePairs(list);
		rdd1.reduceByKey((x,y)->x+y).collect().forEach(System.out::println);
		
				
	}

}
