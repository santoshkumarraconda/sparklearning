package com.jpmc.training.structuredstreams;

import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

public class StrucuredStreamingUtility {
	public static StructType employeeSchema()
	{
		return new StructType(new StructField[] {
			new StructField("id", DataTypes.IntegerType, false, Metadata.empty()),
			new StructField("name", DataTypes.StringType, false, Metadata.empty()),
			new StructField("designation", DataTypes.StringType, false, Metadata.empty())
		});
	}

}
