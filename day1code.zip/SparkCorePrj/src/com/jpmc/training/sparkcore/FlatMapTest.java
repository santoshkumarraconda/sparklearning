package com.jpmc.training.sparkcore;

import java.util.Arrays;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class FlatMapTest {
	public static void main(String[] args) {
		SparkConf conf=new SparkConf();
		conf.setMaster("local[*]");
		conf.setAppName("transformation-test-app");
		JavaSparkContext sc=new JavaSparkContext(conf);
		sc.setLogLevel("WARN");
		
		JavaRDD<String> rdd1=sc.textFile("c:/test/sample.txt");
		JavaRDD<String> wordsRdd=rdd1.flatMap(line->Arrays.asList(line.split(" ")).iterator());
		wordsRdd.collect().forEach(System.out::println);
				
	}

}
