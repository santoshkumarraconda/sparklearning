package com.jpmc.training.sparkstreams;

import java.util.Arrays;

import org.apache.spark.SparkConf;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

import scala.Tuple2;

public class WordCountStreamTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SparkConf conf=new SparkConf();
		conf.setMaster("local[*]");
		conf.setAppName("wordcount-stream-app");
		JavaStreamingContext streamingContext=new JavaStreamingContext(conf,Durations.seconds(60));
		JavaDStream<String> dStream=streamingContext.textFileStream("c:/teststream/test");
		dStream.flatMap(line->Arrays.asList(line.split(" ")).iterator()).
		mapToPair(word->new Tuple2<>(word, 1)).reduceByKey((x,y)->x+y).print();
		streamingContext.start();
		
		System.out.println("streaming started");
		
		try {
			streamingContext.awaitTermination();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
