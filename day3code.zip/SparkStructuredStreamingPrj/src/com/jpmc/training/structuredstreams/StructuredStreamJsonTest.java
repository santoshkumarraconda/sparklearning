package com.jpmc.training.structuredstreams;

import java.util.concurrent.TimeoutException;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.apache.spark.sql.streaming.Trigger;

public class StructuredStreamJsonTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SparkSession spark=SparkSession.builder().appName("structured-json-stream-app")
                .master("local[*]").getOrCreate();

		spark.sparkContext().setLogLevel("WARN");
		String inputDirectory="C:/structuredstreams/json";
		Dataset<Row> df=spark.readStream().schema(StrucuredStreamingUtility.employeeSchema())
				.json(inputDirectory);
		try {
			StreamingQuery query=df.writeStream().trigger(Trigger.ProcessingTime("1 minute"))
					
					.format("console").
					option("checkpointLocation", "c:/testchkpoint")
					.start();
			System.out.println("streaming started");
			query.awaitTermination();
		} catch (TimeoutException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (StreamingQueryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
